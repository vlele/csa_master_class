﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudSample.Web.Services
{
    public class CloudSampleEventSource : EventSource
    {
        private static readonly Lazy<CloudSampleEventSource> Instance = new Lazy<CloudSampleEventSource>(() => new CloudSampleEventSource());

        public static CloudSampleEventSource Log 
        {
            get
            {
                return Instance.Value;
            }
        }

        [Event(7001, Level=EventLevel.Informational, Message="Search called ... ")]
        public void SearchCalled(string firtName, string lastName) 
        {
            if (this.IsEnabled()) 
            {
                WriteEvent(7001, firtName, lastName);
            }
        }
    }
}
