﻿using CloudSample.Web.Entities;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web.Helpers;
using System.Xml;

namespace CloudSample.Web.Services
{
    public class CourseService 
    {
        const string serviceUrl = "https://www.pluralsight.com/courses.rss.xml";
        const string apiKey = ""; 

        public CourseService()
        {
        }

        public IEnumerable<string> GetCourses(string courseName)
        {
            using (var client = new HttpClient())
            {
                var scoreRequest = new
                {
                    Inputs = new Dictionary<string, StringTable>() 
                    { 
                        { 
                            "input1", 
                            new StringTable() 
                            {
                                ColumnNames = new string[] {"CourseName"},
                                Values = new string[,] {  { courseName } }
                            }
                        },
                    },
                    GlobalParameters = new Dictionary<string, string>()
                    {
                    }
                };
                
                client.BaseAddress = new Uri(serviceUrl);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

                List<string> courses = new List<string>();

                try
                {
                    HttpResponseMessage response = client.PostAsJsonAsync("", scoreRequest).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        string xmlString = response.Content.ReadAsStringAsync().Result;
                        XmlDocument doc = new XmlDocument();
                        doc.LoadXml(xmlString);
                        string jsonString = JsonConvert.SerializeXmlNode(doc);
                        dynamic courseResult = Json.Decode(jsonString);
                        foreach (var course in courseResult.rss.channel.item)
                        {
                            string courseTitle = Convert.ToString(course.title);
                            if (courseName.Equals("") || courseTitle.Contains(courseName))
                            {
                                courses.Add(Convert.ToString(course.title));
                            }
                            
                        }
                    }
                }
                catch (Exception ex)
                {
                    courses.Add(ex.Message);
                    courses.Add(ex.StackTrace);
                }

                return courses;
            }
        }

        class StringTable
        {
            public string[] ColumnNames { get; set; }

            public string[,] Values { get; set; }
        }
    }

}
