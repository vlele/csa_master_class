﻿using CloudSample.Web.Entities;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudSample.Web.Services
{
    public class EmailService : TableService
    {
        private string tableName = "email";

        public EmailService() : base()
        {
        }

        public void Insert(string to, string message, string thandle, string status)
        {
            CloudTable emailTable = this.GetTableReference(tableName);
            if (emailTable == null) return;

            TableOperation insertOperation = TableOperation.Insert(new Email()
            {
                PartitionKey = thandle,
                RowKey = Guid.NewGuid().ToString(),
                To = to,
                Message = message,
                Status = status
            });

            emailTable.Execute(insertOperation);
        }
    }
}
