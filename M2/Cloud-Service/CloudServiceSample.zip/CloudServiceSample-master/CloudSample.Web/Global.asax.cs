﻿using CloudSample.Web.Services;
using Microsoft.Practices.EnterpriseLibrary.SemanticLogging;
using Microsoft.WindowsAzure;
using System;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace CloudSample.Web
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            ObservableEventListener listener = new ObservableEventListener();
            listener.EnableEvents(CloudSampleEventSource.Log, EventLevel.LogAlways, Keywords.All);
            listener.LogToWindowsAzureTable("CloudSampleEventsDev", CloudConfigurationManager.GetSetting("StorageAccount.ConnectionString"));
        }
    }
}
