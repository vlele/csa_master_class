﻿$(function () {
    $("#aCourses").attr("href", Url.Course);
    $("#aBackOff").attr("href", Url.BackOff);
    $("#aAuthorPage").attr("href", Url.Author);
});